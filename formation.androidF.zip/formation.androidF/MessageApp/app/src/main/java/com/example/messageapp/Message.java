package com.example.messageapp;

import android.text.format.Time;

public class Message {
    private  String sender;
    private  String message;
    private String Time;

    private  int id;

    public Message() {
    }

    public Message(String sender, String message,String Time) {
        this.sender = sender;
        this.message = message;
        this.Time=Time;
    }

    public Message(int id, String sender, String message,String Time) {
        this.sender = sender;
        this.message = message;
        this.id = id;
        this.Time=Time;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getSender() {
        return sender;
    }


    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
