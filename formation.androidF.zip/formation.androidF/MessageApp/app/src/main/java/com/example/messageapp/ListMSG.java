package com.example.messageapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class ListMSG extends AppCompatActivity {
 ListView lst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_msg);
        lst =findViewById(R.id.list);
        DBMsg db = new DBMsg(this);
        ArrayList<Message> MessgeArrayList = db.getAllMessage();
        Adapter adapter = new Adapter(this, MessgeArrayList);
        lst.setAdapter(adapter);
        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               Message mesg= (Message) parent.getItemAtPosition(position);

                Intent intent = new Intent(ListMSG.this,updateMsg.class);
                int id1=mesg.getId();
                intent.putExtra("id",id1);
                startActivity(intent);

            }
        });




    }
    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        getMenuInflater().inflate(R.menu.add_menu, menu);

        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        if (item.getItemId() == R.id.add) {
            Intent intent = new Intent(ListMSG.this,SendMessage.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);


    }
}
