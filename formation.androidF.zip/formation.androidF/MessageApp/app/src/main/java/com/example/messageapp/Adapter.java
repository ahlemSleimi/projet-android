package com.example.messageapp;

import android.content.Context;
import android.content.Intent;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.List;

import static android.content.Intent.getIntent;

public class Adapter extends ArrayAdapter<Message> {
   Context cnt;
    public Adapter(Context context, List<Message>objects) {
        super(context,R.layout.model, objects);
        this.cnt=context;
    }
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView= LayoutInflater.from(cnt).inflate(R.layout.model,parent,false);
        // convert view bech trakeb model sur liste
        TextView time=convertView.findViewById(R.id.Time);
        //TimePicker tp =convertView.findViewById(R.id.Time);
        TextView message =convertView.findViewById(R.id.textmsg);
        TextView sender=convertView.findViewById(R.id.textsender);

        Message messg =getItem(position);

       // time.setText(messg.getTime());


       time.setText(messg.getTime());
        message.setText(messg.getMessage());
        sender.setText(""+messg.getSender());

   return convertView; }

}
