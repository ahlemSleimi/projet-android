package com.example.messageapp;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.Time;
import android.view.MenuItem;
import android.view.View;
import android.view.autofill.AutofillValue;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

import static android.app.PendingIntent.getActivity;

public class SendMessage extends AppCompatActivity {
    Button sendM;
    EditText Sender,msg,time;

    TimePickerDialog picker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);
        sendM=findViewById(R.id.send);
        Sender =findViewById(R.id.sender);
        msg=findViewById(R.id.msg);
        time=findViewById(R.id.timeP);


        sendM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sender=Sender.getText().toString();
                String message= msg.getText().toString();
                String Time=time.getText().toString();
                String str=Time.substring(0,5);
                Message mesg =new Message(sender,message,str);
                DBMsg db=new DBMsg(SendMessage.this);
                // acces ala methode

                db.ajoutMessage(mesg);
               // String a =mesg.getTime();


                //Toast.makeText(SendMessage.this, "le temp est "+a, Toast.LENGTH_SHORT).show();
              Intent intent =new Intent(SendMessage.this,ListMSG.class);
               startActivity(intent);
            }
        });




        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int hour = cldr.get(Calendar.HOUR_OF_DAY);
                int minutes = cldr.get(Calendar.MINUTE);
                // time picker dialog
                picker = new TimePickerDialog(SendMessage.this,new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker tp, int sHour, int sMinute) {
                                String AM_PM;
                                if (sHour >=0 && sHour < 12){
                                    AM_PM = "AM";
                                } else {
                                    AM_PM = "PM";
                                }
                                time.setText(sHour + ":" + sMinute+" "+AM_PM);
                            }
                        }, hour, minutes, false);
                picker.show();
            }
        });


    }


}