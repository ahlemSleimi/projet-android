package com.example.messageapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBMsg extends SQLiteOpenHelper {
    private static final String DB_Name="dbmsg";
    private static final int version= 1;
    private static final String TB_Name= "messg";

    public DBMsg( Context context) {
        super(context,DB_Name, null, version);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        String create="CREATE TABLE "+TB_Name +" (id integer PRiMARY KEY,sender varchar(20),message varchar(150),time varchar(10));";
        db.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String delete="DROP TABLE IF EXISTS "+TB_Name;
        db.execSQL(delete);
        onCreate(db);
    }
    public void ajoutMessage (Message message)
    {

        SQLiteDatabase db=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("sender",message.getSender());
        values.put("message",message.getMessage());
        values.put("time",message.getTime());
        db.insert(TB_Name,null,values);

    }

    public ArrayList<Message> getAllMessage(){
        SQLiteDatabase db=getReadableDatabase();
        // liste car type de retour
        ArrayList<Message> Array=new ArrayList<Message>();
        // requete
        String query="SELECT * FROM "+TB_Name;
        // raw queryy kifeh bech ya9ralna
        Cursor cursor=db.rawQuery(query,null);
        // verifier si  table est plaine
        if(cursor.moveToFirst()){

            do {
                int id =cursor.getInt(cursor.getColumnIndex("id"));
                String sender =cursor.getString(cursor.getColumnIndex("sender"));
                String Message=cursor.getString(cursor.getColumnIndex("message"));
                String Time=cursor.getString(cursor.getColumnIndex("time"));
                Message msg= new Message(id,sender,Message,Time);
                Array.add(msg);
            }



            while(cursor.moveToNext());

        }
        return Array;
    }
    // bech na9ra mel base de Donnee
    // requete eli bech tlawejli bel id
    public Message getMessageById(int id){

        SQLiteDatabase db=getReadableDatabase();
        String query="SELECT * FROM "+TB_Name+" where id ="+id;
        Cursor cursor=db.rawQuery(query,null);// null c la condition dans un tab de string
        Message msg =null;
        if(cursor.moveToFirst()){
            int id_c =cursor.getInt(cursor.getColumnIndex("id"));
            String sender_c =cursor.getString(cursor.getColumnIndex("sender"));
            String message_c =cursor.getString(cursor.getColumnIndex("message"));
            String Time_c =cursor.getString(cursor.getColumnIndex("time"));
            msg =new Message(id_c,sender_c,message_c,Time_c);


        }
        return msg; }
    public Message UpdateMesssage (Message msg)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("sender",msg.getSender());// key and value
        values.put("message",msg.getMessage());
        values.put("Time",msg.getTime());
        db.update(TB_Name,values,"id=?",new String[]{String.valueOf(msg.getId())});

        return msg; }



    public  void delete(int id){
        // pour delete write

        SQLiteDatabase db=getWritableDatabase();
        db.delete(TB_Name,"id=?",new String[]{String.valueOf(id)});
    }
}
