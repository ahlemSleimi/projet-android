package com.example.messageapp;

import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class updateMsg extends AppCompatActivity {
    EditText updatesend,updatmsg,time;int id;
    Button update;
    TimePickerDialog picker;
    DBMsg db =new DBMsg(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_msg);
        updatmsg=findViewById(R.id.msgU);
        updatesend=findViewById(R.id.senderU);
        time=findViewById(R.id.timePU);
        update=findViewById(R.id.update);
        Intent intent=getIntent();
        id =intent.getIntExtra("id",0);
        Message message= db.getMessageById(id);
        updatesend.setText(message.getSender());
        updatmsg.setText(""+message.getMessage());
        time.setText(message.getTime());
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nom=updatesend.getText().toString();
                String msg=updatmsg.getText().toString();
                String Time=time.getText().toString();

                Message messag =new Message(id,nom,msg,Time);// id il est oblig car pour lui acceder
                db.UpdateMesssage(messag);
                Toast.makeText(updateMsg.this, "contact update...", Toast.LENGTH_SHORT).show();
                Intent intent =new Intent (updateMsg.this,ListMSG.class);
                startActivity(intent);

            }
        });
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int hour = cldr.get(Calendar.HOUR_OF_DAY);
                int minutes = cldr.get(Calendar.MINUTE);
                // time picker dialog
                picker = new TimePickerDialog(updateMsg.this,new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker tp, int sHour, int sMinute) {
                        String AM_PM;
                        if (sHour >=0 && sHour < 12){
                            AM_PM = "AM";
                        } else {
                            AM_PM = "PM";
                        }
                        time.setText(sHour + ":" + sMinute+" "+AM_PM);
                    }
                }, hour, minutes, false);
                picker.show();
            }
        });

    }
    // pour l'option delete se sont des methode predefinit
    public boolean onCreateOptionsMenu (Menu menu){
        getMenuInflater().inflate(R.menu.delete, menu);

        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        if (item.getItemId() == R.id.delete) {
            showPopUp();

        }
        return super.onOptionsItemSelected(item);


    }
    public void showPopUp(){
        AlertDialog.Builder builder= new AlertDialog.Builder(this).setTitle("press yes to confirm").setMessage("you want to delete this contact").setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                db.delete(id);
                Toast.makeText(updateMsg.this, "message is deleted", Toast.LENGTH_SHORT).show();
                Intent intent =new Intent(updateMsg.this,ListMSG.class);
                startActivity(intent);
            }
        }).setNegativeButton("no", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

            }
        });
        AlertDialog alertDialog =builder.create();
        alertDialog.show();
        alertDialog.getWindow().setBackgroundDrawableResource(android.R.color.holo_orange_light);
    }

}







